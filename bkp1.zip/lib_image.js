/**
 * FileConvert - lib_image.js
 * Conversão de imagens local usando Canvas API
 */

window.imageConverter = {
    file: null,
    loadedImage: null,

    render: function () {
        return `
            <div class="glass-card p-6 md:p-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div class="flex items-center gap-4 mb-8">
                    <div class="w-12 h-12 bg-cyan-500/20 rounded-full flex items-center justify-center text-2xl">🖼️</div>
                    <div>
                        <h2 class="text-2xl font-bold">Conversor de Imagem</h2>
                        <p class="text-gray-400 text-sm">PNG, JPEG e WebP com compressão de alta fidelidade.</p>
                    </div>
                </div>

                <div id="image-drop-zone" class="border-2 border-dashed border-white/10 rounded-2xl p-10 text-center cursor-pointer hover:border-cyan-500/50 transition-all hover:bg-white/5 mb-8">
                    <div class="text-4xl mb-4">📸</div>
                    <p class="text-lg font-medium">Solte sua imagem aqui</p>
                    <p class="text-gray-500 text-sm mt-1">PNG, JPG, WebP, GIF ou BMP</p>
                    <input type="file" id="image-input" accept="image/*" class="hidden">
                </div>

                <div id="image-preview-area" class="hidden grid grid-cols-1 md:grid-cols-2 gap-8 mb-8 p-6 bg-white/5 rounded-2xl border border-white/10">
                    <div class="flex items-center justify-center bg-black/40 rounded-xl overflow-hidden min-h-[200px]">
                        <img id="image-preview" class="max-h-64 object-contain shadow-2xl">
                    </div>
                    <div class="flex flex-col justify-center space-y-4">
                        <div>
                            <p id="image-filename" class="font-bold truncate text-lg">imagem.png</p>
                            <p id="image-info" class="text-sm text-gray-500">1920x1080 - 1.2 MB</p>
                        </div>
                        <div class="space-y-4">
                            <div class="space-y-1">
                                <div class="flex justify-between text-xs text-gray-400">
                                    <span>Qualidade</span>
                                    <span id="quality-val">90%</span>
                                </div>
                                <input type="range" id="image-quality" min="1" max="100" value="90" class="w-full accent-cyan-500">
                            </div>
                            <div class="grid grid-cols-2 gap-4">
                                <input type="number" id="img-width" placeholder="Largura (px)" class="text-sm">
                                <input type="number" id="img-height" placeholder="Altura (px)" class="text-sm">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div class="space-y-2">
                        <label class="text-sm font-semibold text-gray-400">Formato de Saída</label>
                        <select id="image-output-format" class="w-full">
                            <option value="webp" selected>WebP (Recomendado)</option>
                            <option value="png">PNG (Transparência)</option>
                            <option value="jpeg">JPEG (Padrão)</option>
                        </select>
                    </div>
                    <div class="flex items-end">
                        <button id="image-convert-btn" class="btn-primary w-full py-3" style="background: linear-gradient(135deg, #06b6d4 0%, #3b82f6 100%)" disabled>
                            Converter e Otimizar
                        </button>
                    </div>
                </div>
            </div>
        `;
    },

    init: function () {
        utils.setupDropZone('image-drop-zone', 'image-input', (file) => this.handleFile(file));

        const qualitySlider = document.getElementById('image-quality');
        if (qualitySlider) {
            qualitySlider.oninput = (e) => {
                document.getElementById('quality-val').textContent = e.target.value + '%';
            };
        }

        document.getElementById('image-convert-btn').onclick = () => this.startConversion();
    },

    handleFile: function (file) {
        this.file = file;
        const img = new Image();
        img.onload = () => {
            this.loadedImage = img;
            document.getElementById('image-preview').src = img.src;
            document.getElementById('image-filename').textContent = file.name;
            document.getElementById('image-info').textContent = `${img.width}x${img.height} - ${utils.formatBytes(file.size)}`;
            document.getElementById('image-preview-area').classList.remove('hidden');
            document.getElementById('image-convert-btn').disabled = false;
            app.showToast('Imagem carregada!');
        };
        img.src = URL.createObjectURL(file);
    },

    startConversion: function () {
        if (!this.loadedImage) return;

        app.showLoader('Otimizando Imagem...');

        const format = document.getElementById('image-output-format').value;
        const quality = document.getElementById('image-quality').value / 100;
        const targetW = document.getElementById('img-width').value;
        const targetH = document.getElementById('img-height').value;

        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');

        let w = this.loadedImage.width;
        let h = this.loadedImage.height;

        if (targetW && targetH) {
            w = parseInt(targetW);
            h = parseInt(targetH);
        } else if (targetW) {
            w = parseInt(targetW);
            h = Math.round((this.loadedImage.height / this.loadedImage.width) * w);
        } else if (targetH) {
            h = parseInt(targetH);
            w = Math.round((this.loadedImage.width / this.loadedImage.height) * h);
        }

        canvas.width = w;
        canvas.height = h;

        if (format === 'jpeg') {
            ctx.fillStyle = '#FFFFFF';
            ctx.fillRect(0, 0, w, h);
        }

        ctx.drawImage(this.loadedImage, 0, 0, w, h);

        const mime = { 'webp': 'image/webp', 'png': 'image/png', 'jpeg': 'image/jpeg' };
        const ext = { 'webp': 'webp', 'png': 'png', 'jpeg': 'jpg' };

        canvas.toBlob((blob) => {
            app.hideLoader();
            if (blob) {
                utils.downloadBlob(blob, this.file.name.replace(/\.[^.]+$/, '.' + ext[format]));
                utils.logHistory({
                    nome: this.file.name,
                    de: this.file.name.split('.').pop().toUpperCase(),
                    para: format.toUpperCase(),
                    tamanho: this.file.size
                });
                app.showToast('Imagem convertida com sucesso!', '✨');
            } else {
                app.showToast('Erro ao processar imagem', '❌');
            }
        }, mime[format], quality);
    }
};
