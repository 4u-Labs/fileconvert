/**
 * FileConvert - lib_tools.js
 * Ferramentas diversas: QR Code, ZIP, Base64 e Hash
 */

window.toolsConverter = {
    render: function () {
        return `
            <div class="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-8">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- Base64 -->
                    <div class="glass-card p-6 space-y-4">
                        <h3 class="text-lg font-bold">🔐 Base64 ↔ Arquivo</h3>
                        <input type="file" id="b64-file" class="text-xs w-full">
                        <textarea id="b64-text" placeholder="Cole Base64 aqui..." class="w-full h-20 text-xs"></textarea>
                        <div class="flex gap-2">
                            <button id="b64-enc" class="btn-primary flex-1 py-1 text-xs">Codificar</button>
                            <button id="b64-dec" class="btn-primary flex-1 py-1 text-xs">Decodificar</button>
                        </div>
                    </div>

                    <!-- QR Code -->
                    <div class="glass-card p-6 space-y-4 text-center">
                        <h3 class="text-lg font-bold">📱 Gerar QR Code</h3>
                        <input type="text" id="qr-input" placeholder="Texto ou URL..." class="w-full text-xs">
                        <div id="qr-code-result" class="bg-white p-2 border-4 border-indigo-500/20 inline-block rounded-xl min-w-[128px] min-h-[128px]"></div>
                        <button id="qr-btn" class="btn-primary w-full py-2 text-sm">Gerar Agora</button>
                    </div>

                    <!-- Hash -->
                    <div class="glass-card p-6 space-y-4">
                        <h3 class="text-lg font-bold">🔒 Gerador de Hash</h3>
                        <textarea id="hash-input" placeholder="Texto para hash..." class="w-full h-20 text-xs"></textarea>
                        <select id="hash-algo" class="w-full text-xs">
                            <option value="SHA-256">SHA-256</option>
                            <option value="SHA-512">SHA-512</option>
                        </select>
                        <button id="hash-btn" class="btn-primary w-full py-2 text-sm">Gerar Hash Seguro</button>
                        <div id="hash-res" class="p-2 bg-black/40 rounded text-[10px] break-all hidden font-mono"></div>
                    </div>

                    <!-- ZIP -->
                    <div class="glass-card p-6 space-y-4">
                        <h3 class="text-lg font-bold">📦 Compactador ZIP</h3>
                        <input type="file" id="zip-input" multiple class="text-xs w-full">
                        <button id="zip-btn" class="btn-primary w-full py-2 text-sm">Criar Pacote ZIP</button>
                    </div>
                </div>
            </div>
        `;
    },

    init: function () {
        document.getElementById('b64-enc').onclick = () => this.base64Enc();
        document.getElementById('qr-btn').onclick = () => this.generateQR();
        document.getElementById('hash-btn').onclick = () => this.generateHash();
        document.getElementById('zip-btn').onclick = () => this.createZip();
    },

    base64Enc: function () {
        const file = document.getElementById('b64-file').files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            document.getElementById('b64-text').value = e.target.result.split(',')[1];
            app.showToast('Base64 gerado!');
        };
        reader.readAsDataURL(file);
    },

    generateQR: function () {
        const text = document.getElementById('qr-input').value;
        const result = document.getElementById('qr-code-result');
        if (!text) return;
        result.innerHTML = '';
        new QRCode(result, { text: text, width: 128, height: 128 });
        app.showToast('QR Code renovado!');
    },

    generateHash: async function () {
        const text = document.getElementById('hash-input').value;
        const algo = document.getElementById('hash-algo').value;
        if (!text) return;

        const msgUint8 = new TextEncoder().encode(text);
        const hashBuffer = await crypto.subtle.digest(algo, msgUint8);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

        const res = document.getElementById('hash-res');
        res.textContent = hashHex;
        res.classList.remove('hidden');
        app.showToast('Hash gerado!');
    },

    createZip: function () {
        const files = document.getElementById('zip-input').files;
        if (files.length === 0) return;

        const zip = new JSZip();
        for (let f of files) zip.file(f.name, f);

        zip.generateAsync({ type: "blob" }).then(content => {
            utils.downloadBlob(content, "pacote_fileconvert.zip");
            app.showToast('ZIP criado com sucesso!');
        });
    }
};

// Registro no render
window.app.renderTabContent = (function (original) {
    return function (tabName) {
        if (tabName === 'other' && window.toolsConverter) {
            document.getElementById('tab-content').innerHTML = window.toolsConverter.render();
            window.toolsConverter.init();
        } else {
            original.call(this, tabName);
        }
    };
})(window.app.renderTabContent);
