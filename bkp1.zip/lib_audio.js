/**
 * FileConvert - lib_audio.js
 * Conversão de áudio local usando lamejs
 */

window.audioConverter = {
    file: null,
    audioBuffer: null,

    render: function () {
        return `
            <div class="glass-card p-6 md:p-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div class="flex items-center gap-4 mb-8">
                    <div class="w-12 h-12 bg-indigo-500/20 rounded-full flex items-center justify-center text-2xl">🎵</div>
                    <div>
                        <h2 class="text-2xl font-bold">Conversor de Áudio</h2>
                        <p class="text-gray-400 text-sm">Converta WAV, OGG, FLAC para MP3 ou WAV localmente.</p>
                    </div>
                </div>

                <div id="audio-drop-zone" class="border-2 border-dashed border-white/10 rounded-2xl p-10 text-center cursor-pointer hover:border-indigo-500/50 transition-all hover:bg-white/5 mb-8">
                    <div class="text-4xl mb-4">📁</div>
                    <p class="text-lg font-medium">Solte seu áudio aqui</p>
                    <p class="text-gray-500 text-sm mt-1">ou clique para selecionar do computador</p>
                    <input type="file" id="audio-input" accept="audio/*" class="hidden">
                </div>

                <div id="audio-preview-area" class="hidden mb-8 p-4 bg-white/5 rounded-xl border border-white/10">
                    <div class="flex justify-between items-center mb-4">
                        <span id="audio-filename" class="font-medium truncate max-w-[200px]">arquivo.mp3</span>
                        <span id="audio-filesize" class="text-xs text-gray-500">0 MB</span>
                    </div>
                    <audio id="audio-player" controls class="w-full h-8"></audio>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div class="space-y-2">
                        <label class="text-sm font-semibold text-gray-400">Formato de Saída</label>
                        <select id="audio-output-format" class="w-full">
                            <option value="mp3">MP3 (Universal)</option>
                            <option value="wav">WAV (Lossless)</option>
                        </select>
                    </div>
                    <div class="space-y-2">
                        <label class="text-sm font-semibold text-gray-400">Bitrate (MP3)</label>
                        <select id="audio-bitrate" class="w-full">
                            <option value="128">128 kbps</option>
                            <option value="192" selected>192 kbps</option>
                            <option value="320">320 kbps</option>
                        </select>
                    </div>
                    <div class="space-y-2">
                        <label class="text-sm font-semibold text-gray-400">Canais</label>
                        <select id="audio-channels" class="w-full">
                            <option value="2">Estéreo</option>
                            <option value="1">Mono</option>
                        </select>
                    </div>
                </div>

                <button id="audio-convert-btn" class="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed py-4" disabled>
                    Iniciar Conversão Premium
                </button>

                <div id="audio-progress-container" class="hidden mt-8">
                    <div class="w-full bg-white/5 rounded-full h-2 mb-2 overflow-hidden">
                        <div id="audio-progress-bar" class="h-full bg-indigo-500 transition-all duration-300" style="width: 0%"></div>
                    </div>
                    <p id="audio-progress-text" class="text-center text-xs text-gray-400">Preparando...</p>
                </div>
            </div>
        `;
    },

    init: function () {
        utils.setupDropZone('audio-drop-zone', 'audio-input', (file) => this.handleFile(file));

        document.getElementById('audio-convert-btn').onclick = () => this.startConversion();
    },

    handleFile: function (file) {
        this.file = file;
        const player = document.getElementById('audio-player');
        const preview = document.getElementById('audio-preview-area');

        player.src = URL.createObjectURL(file);
        document.getElementById('audio-filename').textContent = file.name;
        document.getElementById('audio-filesize').textContent = utils.formatBytes(file.size);

        preview.classList.remove('hidden');
        document.getElementById('audio-convert-btn').disabled = false;
        app.showToast('Áudio carregado com sucesso!');
    },

    startConversion: async function () {
        if (!this.file) return;

        const btn = document.getElementById('audio-convert-btn');
        const progressCont = document.getElementById('audio-progress-container');
        const progressBar = document.getElementById('audio-progress-bar');
        const progressText = document.getElementById('audio-progress-text');

        btn.disabled = true;
        progressCont.classList.remove('hidden');
        app.showLoader('Decodificando Áudio...');

        try {
            const arrayBuffer = await this.file.arrayBuffer();
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            this.audioBuffer = await audioContext.decodeAudioData(arrayBuffer);

            app.hideLoader();
            const format = document.getElementById('audio-output-format').value;

            if (format === 'mp3') {
                await this.convertToMp3(progressBar, progressText);
            } else {
                await this.convertToWav(progressBar, progressText);
            }

            // Log no histórico
            utils.logHistory({
                nome: this.file.name,
                de: this.file.name.split('.').pop().toUpperCase(),
                para: format.toUpperCase(),
                tamanho: this.file.size
            });

            app.showToast('Conversão concluída!', '✅');
        } catch (e) {
            console.error(e);
            app.showToast('Erro na conversão: ' + e.message, '❌');
            app.hideLoader();
        } finally {
            btn.disabled = false;
        }
    },

    convertToMp3: async function (bar, text) {
        const bitrate = parseInt(document.getElementById('audio-bitrate').value);
        const channels = parseInt(document.getElementById('audio-channels').value);
        const sampleRate = this.audioBuffer.sampleRate;

        const encoder = new lamejs.Mp3Encoder(channels, sampleRate, bitrate);
        const mp3Data = [];
        const blockSize = 1152;

        const left = this.audioBuffer.getChannelData(0);
        const right = channels === 2 && this.audioBuffer.numberOfChannels > 1 ? this.audioBuffer.getChannelData(1) : left;

        for (let i = 0; i < left.length; i += blockSize) {
            const lChunk = this.convertFloat32ToInt16(left.subarray(i, i + blockSize));
            const rChunk = channels === 2 ? this.convertFloat32ToInt16(right.subarray(i, i + blockSize)) : null;

            const buf = channels === 2 ? encoder.encodeBuffer(lChunk, rChunk) : encoder.encodeBuffer(lChunk);
            if (buf.length > 0) mp3Data.push(buf);

            if (i % (blockSize * 50) === 0) {
                const p = (i / left.length) * 100;
                bar.style.width = p + '%';
                text.textContent = `Convertendo: ${Math.round(p)}%`;
                await new Promise(r => setTimeout(r, 0));
            }
        }

        const final = encoder.flush();
        if (final.length > 0) mp3Data.push(final);

        const blob = new Blob(mp3Data, { type: 'audio/mp3' });
        utils.downloadBlob(blob, this.file.name.replace(/\.[^.]+$/, '.mp3'));
        bar.style.width = '100%';
        text.textContent = '✅ Concluído!';
    },

    convertToWav: async function (bar, text) {
        // Implementação simplificada baseada no código original
        const numChannels = this.audioBuffer.numberOfChannels;
        const sampleRate = this.audioBuffer.sampleRate;
        const length = this.audioBuffer.length * numChannels * 2;
        const buffer = new ArrayBuffer(44 + length);
        const view = new DataView(buffer);

        const writeString = (offset, str) => {
            for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
        };

        writeString(0, 'RIFF');
        view.setUint32(4, 36 + length, true);
        writeString(8, 'WAVE');
        writeString(12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, 1, true);
        view.setUint16(22, numChannels, true);
        view.setUint32(24, sampleRate, true);
        view.setUint32(28, sampleRate * numChannels * 2, true);
        view.setUint16(32, numChannels * 2, true);
        view.setUint16(34, 16, true);
        writeString(36, 'data');
        view.setUint32(40, length, true);

        const channels = [];
        for (let i = 0; i < numChannels; i++) channels.push(this.audioBuffer.getChannelData(i));

        let offset = 44;
        for (let i = 0; i < this.audioBuffer.length; i++) {
            for (let ch = 0; ch < numChannels; ch++) {
                const s = Math.max(-1, Math.min(1, channels[ch][i]));
                view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
                offset += 2;
            }
            if (i % 50000 === 0) {
                const p = (i / this.audioBuffer.length) * 100;
                bar.style.width = p + '%';
                text.textContent = `Embalando WAV: ${Math.round(p)}%`;
                await new Promise(r => setTimeout(r, 0));
            }
        }

        utils.downloadBlob(new Blob([buffer], { type: 'audio/wav' }), this.file.name.replace(/\.[^.]+$/, '.wav'));
        bar.style.width = '100%';
        text.textContent = '✅ Concluído!';
    },

    convertFloat32ToInt16: function (buffer) {
        const l = buffer.length;
        const buf = new Int16Array(l);
        for (let i = 0; i < l; i++) {
            const s = Math.max(-1, Math.min(1, buffer[i]));
            buf[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
        }
        return buf;
    }
};
