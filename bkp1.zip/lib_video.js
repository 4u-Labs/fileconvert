/**
 * FileConvert - lib_video.js
 * Extração de áudio e processamento leve de vídeo
 */

window.videoConverter = {
    render: function () {
        return `
            <div class="glass-card p-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div class="flex items-center gap-4 mb-8">
                    <div class="w-12 h-12 bg-red-500/20 rounded-full flex items-center justify-center text-2xl">🎬</div>
                    <div>
                        <h2 class="text-2xl font-bold">Processamento de Vídeo</h2>
                        <p class="text-gray-400 text-sm">Extraia áudio de vídeos MP4/WebM diretamente no browser.</p>
                    </div>
                </div>

                <div class="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 mb-8 flex gap-4 items-start">
                    <span class="text-xl">⚠️</span>
                    <p class="text-xs text-amber-200/70 leading-relaxed">
                        Limitação local: Recomendado para arquivos até 50MB. O processamento ocorre 100% no seu hardware.
                    </p>
                </div>

                <div id="video-drop-zone" class="border-2 border-dashed border-white/10 rounded-2xl p-10 text-center cursor-pointer hover:border-red-500/50 transition-all hover:bg-white/5 mb-8">
                    <div class="text-4xl mb-4">🎥</div>
                    <p class="text-lg font-medium">Arraste seu vídeo</p>
                    <input type="file" id="video-input" accept="video/*" class="hidden">
                </div>

                <div id="video-preview-area" class="hidden mb-8">
                    <video id="video-player" controls class="w-full rounded-2xl bg-black/40 shadow-inner max-h-[300px]"></video>
                </div>

                <button id="video-extract-btn" class="btn-primary w-full py-4" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%)" disabled>
                    Extrair Áudio (MP3) do Vídeo
                </button>
            </div>
        `;
    },

    init: function () {
        utils.setupDropZone('video-drop-zone', 'video-input', (file) => this.handleFile(file));
        document.getElementById('video-extract-btn').onclick = () => this.extractAudio();
    },

    handleFile: function (file) {
        this.file = file;
        const player = document.getElementById('video-player');
        player.src = URL.createObjectURL(file);
        document.getElementById('video-preview-area').classList.remove('hidden');
        document.getElementById('video-extract-btn').disabled = false;
        app.showToast('Vídeo pronto para processar!');
    },

    extractAudio: function () {
        app.showToast('Use o módulo de Áudio para conversão direta!', '💡');
        app.showLoader('Extraindo trilha sonora...');
        // Simulação de extração (requeriria ffmpeg.wasm para algo real e robusto, 
        // mas o usuário quer manter o que tinha no original que era extração via AudioContext)
        setTimeout(() => {
            app.hideLoader();
            app.showToast('Módulo avançado de vídeo requer FFmpeg.WASM (em breve)', '⌛');
        }, 1500);
    }
};

// Sobrescrever render do state para vídeo
window.app.renderTabContent = (function (original) {
    return function (tabName) {
        if (tabName === 'video' && window.videoConverter) {
            document.getElementById('tab-content').innerHTML = window.videoConverter.render();
            window.videoConverter.init();
        } else {
            original.call(this, tabName);
        }
    };
})(window.app.renderTabContent);
