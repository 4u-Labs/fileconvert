/**
 * FileConvert - lib_docs.js
 * Conversores de CSV, JSON, Markdown e PDF
 */

window.docsConverter = {
    render: function () {
        return `
            <div class="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-8">
                <div class="glass-card p-10">
                    <h2 class="text-2xl font-bold mb-6">📊 Dados e Documentos</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <!-- CSV <-> JSON -->
                        <div class="bg-white/5 p-6 rounded-2xl border border-white/5 space-y-4">
                            <h3 class="text-lg font-bold text-indigo-400">CSV ↔ JSON</h3>
                            <p class="text-xs text-gray-500">Converta planilhas para objetos de dados e vice-versa.</p>
                            <input type="file" id="csv-json-input" accept=".csv,.json" class="text-xs w-full">
                            <button id="csv-json-btn" class="btn-primary w-full py-2 text-sm">Converter Dados</button>
                        </div>
                        
                        <!-- MD -> HTML -->
                        <div class="bg-white/5 p-6 rounded-2xl border border-white/5 space-y-4">
                            <h3 class="text-lg font-bold text-orange-400">Markdown → HTML</h3>
                            <textarea id="md-input" placeholder="# Título..." class="w-full h-24 text-xs resize-none"></textarea>
                            <button id="md-btn" class="btn-primary w-full py-2 text-sm" style="background: linear-gradient(135deg, #f97316 0%, #ea580c 100%)">Gerar HTML</button>
                        </div>

                        <!-- Texto -> PDF -->
                        <div class="bg-white/5 p-6 rounded-2xl border border-white/5 space-y-4">
                            <h3 class="text-lg font-bold text-red-400">Texto → PDF</h3>
                            <textarea id="pdf-text-input" placeholder="Digite seu texto..." class="w-full h-24 text-xs resize-none"></textarea>
                            <button id="pdf-btn" class="btn-primary w-full py-2 text-sm" style="background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%)">Criar PDF Premium</button>
                        </div>

                        <!-- JSON <-> XML -->
                        <div class="bg-white/5 p-6 rounded-2xl border border-white/5 space-y-4">
                            <h3 class="text-lg font-bold text-purple-400">JSON ↔ XML</h3>
                            <textarea id="xml-input" placeholder='{"key": "val"} ou <root>...</root>' class="w-full h-24 text-xs resize-none"></textarea>
                            <button id="xml-btn" class="btn-primary w-full py-2 text-sm" style="background: linear-gradient(135deg, #a855f7 0%, #7e22ce 100%)">Converter Estrutura</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    init: function () {
        // CSV <-> JSON
        document.getElementById('csv-json-btn').onclick = () => this.convertCsvJson();
        // MD -> HTML
        document.getElementById('md-btn').onclick = () => this.convertMd();
        // PDF
        document.getElementById('pdf-btn').onclick = () => this.generatePdf();
        // XML
        document.getElementById('xml-btn').onclick = () => this.convertXml();
    },

    convertCsvJson: async function () {
        const file = document.getElementById('csv-json-input').files[0];
        if (!file) return app.showToast('Selecione um arquivo!', '⚠️');

        app.showLoader('Processando Dados...');
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const content = e.target.result;
                if (file.name.endsWith('.csv')) {
                    const lines = content.split('\n').filter(l => l.trim());
                    const headers = lines[0].split(',').map(h => h.trim());
                    const json = lines.slice(1).map(l => {
                        const vals = l.split(',');
                        const o = {};
                        headers.forEach((h, i) => o[h] = vals[i]);
                        return o;
                    });
                    utils.downloadBlob(new Blob([JSON.stringify(json, null, 2)], { type: 'application/json' }), file.name.replace('.csv', '.json'));
                } else {
                    const json = JSON.parse(content);
                    const headers = Object.keys(json[0]);
                    const csv = [headers.join(','), ...json.map(o => headers.map(h => o[h]).join(','))].join('\n');
                    utils.downloadBlob(new Blob([csv], { type: 'text/csv' }), file.name.replace('.json', '.csv'));
                }
                app.showToast('Sucesso!', '✨');
            } catch (err) {
                app.showToast('Erro no formato!', '❌');
            }
            app.hideLoader();
        };
        reader.readAsText(file);
    },

    convertMd: function () {
        const md = document.getElementById('md-input').value;
        if (!md.trim()) return;

        // Parser ultra-simples baseado no original
        let html = md.replace(/^# (.*$)/gim, '<h1>$1</h1>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        const full = `<!DOCTYPE html><html><head><style>body{font-family:sans-serif;padding:40px;line-height:1.6;}</style></head><body>${html}</body></html>`;
        utils.downloadBlob(new Blob([full], { type: 'text/html' }), 'documento.html');
        app.showToast('HTML Gerado!', '📝');
    },

    generatePdf: function () {
        const text = document.getElementById('pdf-text-input').value;
        if (!text.trim()) return;

        try {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            doc.text(doc.splitTextToSize(text, 180), 15, 20);
            doc.save('documento.pdf');
            app.showToast('PDF Criado!', '📕');
        } catch (e) {
            app.showToast('Erro no PDF', '❌');
        }
    },

    convertXml: function () { app.showToast('Módulo XML em breve!', '⌛'); }
};

// Sobrescrever render do state para documentos
window.app.renderTabContent = (function (original) {
    return function (tabName) {
        if (tabName === 'document' && window.docsConverter) {
            document.getElementById('tab-content').innerHTML = window.docsConverter.render();
            window.docsConverter.init();
        } else {
            original.call(this, tabName);
        }
    };
})(window.app.renderTabContent);
