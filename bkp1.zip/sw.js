/**
 * FileConvert - sw.js
 * Service Worker para suporte Offline e Cache
 */

const CACHE_NAME = 'fileconvert-v1';
const ASSETS = [
    './',
    './index.php',
    './style_main.css',
    './lib_state.js',
    './lib_utils.js',
    './lib_audio.js',
    './lib_image.js',
    './lib_docs.js',
    './lib_video.js',
    './manifest.json'
];

self.addEventListener('install', (e) => {
    e.waitUntil(
        caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
    );
});

self.addEventListener('fetch', (e) => {
    e.respondWith(
        caches.match(e.request).then(response => response || fetch(e.request))
    );
});
