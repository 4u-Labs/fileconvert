<footer class="footer-clean py-8 text-center text-gray-500/50">
    <p class="text-[10px] uppercase tracking-[0.2em] opacity-50">&copy; 2026 4U.IA.BR - Todos os direitos reservados</p>
    <div class="mt-4 flex justify-center gap-4 opacity-30">
         <span class="text-[10px] uppercase tracking-wider">Privacidade Garantida 🔒</span>
         <span class="text-[10px] uppercase tracking-wider">Baseado em WebAssembly 🚀</span>
    </div>
</footer>
