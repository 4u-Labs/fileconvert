<header class="glass-nav sticky top-0 z-50">
    <div class="container mx-auto px-6 py-4 flex justify-between items-center">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center text-2xl shadow-lg">
                🔄
            </div>
            <h1 class="text-2xl font-bold bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                FileConvert
            </h1>
        </div>
        <div class="hidden md:flex items-center gap-6 text-sm font-medium text-gray-400">
            <span class="hover:text-white cursor-pointer transition-colors">Local v1.0</span>
            <span class="px-3 py-1 bg-white/5 rounded-full border border-white/10 text-xs">PWA Ready</span>
        </div>
    </div>
</header>
