<?php
/**
 * FileConvert - Conversor Universal Premium
 * Design: Glassmorphism Dark
 */

// Carregar configurações do .env
$env = parse_ini_file('.env');
$app_url = $env['APP_URL'] ?? 'http://localhost';

// Função para anti-cache
function version($file) {
    if (file_exists($file)) {
        return "?v=" . filemtime($file);
    }
    return "";
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FileConvert - Conversor Universal Premium</title>
    
    <!-- Favicon -->
    <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🔄</text></svg>">

    <!-- Bibliotecas Externas -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lamejs/1.2.1/lame.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

    <!-- PWA -->
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#6366f1">

    <!-- Estilos Customizados -->
    <link rel="stylesheet" href="style_main.css<?php echo version('style_main.css'); ?>">
</head>
<body class="area">
    <!-- Fundo Animado -->
    <ul class="circles">
        <li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li>
    </ul>

    <div id="app" class="min-h-screen flex flex-col">
        <?php include 'ui_header.php'; ?>
        
        <main class="flex-grow container mx-auto px-4 py-8">
            <div class="max-w-4xl mx-auto">
                <?php include 'ui_tabs.php'; ?>
                
                <div id="tab-content" class="mt-4">
                    <!-- Conteúdo dinâmico aqui -->
                </div>
            </div>
        </main>

        <?php include 'ui_footer.php'; ?>
    </div>

    <?php include 'ui_components.php'; ?>

    <!-- Scripts -->
    <script src="lib_state.js<?php echo version('lib_state.js'); ?>"></script>
    <script src="lib_utils.js<?php echo version('lib_utils.js'); ?>"></script>
    <script src="lib_audio.js<?php echo version('lib_audio.js'); ?>"></script>
    <script src="lib_image.js<?php echo version('lib_image.js'); ?>"></script>
    <script src="lib_docs.js<?php echo version('lib_docs.js'); ?>"></script>
    <script src="lib_video.js<?php echo version('lib_video.js'); ?>"></script>
    <script src="lib_tools.js<?php echo version('lib_tools.js'); ?>"></script>
    <script>
        // Inicialização do App
        document.addEventListener('DOMContentLoaded', () => {
            if (window.app && typeof window.app.init === 'function') {
                window.app.init();
            }

            // Registrar Service Worker para PWA
            if ('serviceWorker' in navigator) {
                navigator.serviceWorker.register('sw.js');
            }
        });
    </script>
</body>
</html>
