/**
 * FileConvert - lib_utils.js
 * Funções utilitárias e ponte para API
 */

window.utils = {
    // Registro de Histórico no DB via PHP
    logHistory: async function (data) {
        try {
            const formData = new FormData();
            formData.append('action', 'add_history');
            formData.append('nome', data.nome);
            formData.append('de', data.de);
            formData.append('para', data.para);
            formData.append('tamanho', data.tamanho);

            await fetch('api_db.php', {
                method: 'POST',
                body: formData
            });
        } catch (e) {
            console.error('Erro ao salvar histórico:', e);
        }
    },

    formatBytes: function (bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    },

    downloadBlob: function (blob, filename) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    },

    setupDropZone: function (id, inputId, callback) {
        const zone = document.getElementById(id);
        const input = document.getElementById(inputId);

        if (!zone || !input) return;

        zone.onclick = () => input.click();

        zone.ondragover = (e) => {
            e.preventDefault();
            zone.classList.add('border-indigo-500', 'bg-indigo-500/5');
        };

        zone.ondragleave = () => {
            zone.classList.remove('border-indigo-500', 'bg-indigo-500/5');
        };

        zone.ondrop = (e) => {
            e.preventDefault();
            zone.classList.remove('border-indigo-500', 'bg-indigo-500/5');
            if (e.dataTransfer.files.length) callback(e.dataTransfer.files[0]);
        };

        input.onchange = (e) => {
            if (e.target.files.length) callback(e.target.files[0]);
        };
    }
};
